#!/usr/bin/env bash

sudo ln -s "/Applications/Sublime Text.app/Contents/SharedSupport/bin/subl" /usr/local/bin/subl
ln -s "$HOME/Documents/osx/sublime_text/Default (OSX).sublime-keymap"          "$HOME/Library/Application Support/Sublime Text 3/Packages/User/Default (OSX).sublime-keymap"
ln -s "$HOME/Documents/osx/sublime_text/Preferences.sublime-settings"          "$HOME/Library/Application Support/Sublime Text 3/Packages/User/Preferences.sublime-settings"
ln -s "$HOME/Documents/osx/sublime_text/nico.tmTheme"                          "$HOME/Library/Application Support/Sublime Text 3/Packages/User/nico.tmTheme"
ln -s "$HOME/Documents/osx/sublime_text/Markdown.sublime-settings"             "$HOME/Library/Application Support/Sublime Text 3/Packages/User/Markdown.sublime-settings"
ln -s "$HOME/Documents/osx/sublime_text/Marked.sublime-build"                  "$HOME/Library/Application Support/Sublime Text 3/Packages/User/Marked.sublime-build"
ln -s "$HOME/Documents/osx/sublime_text/html5.sublime-snippet"                 "$HOME/Library/Application Support/Sublime Text 3/Packages/User/html5.sublime-snippet"
ln -s "$HOME/Documents/osx/sublime_text/python_shebang.sublime-snippet"        "$HOME/Library/Application Support/Sublime Text 3/Packages/User/python_shebang.sublime-snippet"
ln -s "$HOME/Documents/osx/sublime_text/jobup.sublime-snippet"                 "$HOME/Library/Application Support/Sublime Text 3/Packages/User/jobup.sublime-snippet"
