// WS28.h  ref 170402
#include <Arduino.h>  // replace next definitions
//typedef uint8_t byte;
//#define bitSet(x,y) x|=(1<<y)
//#define bitClear(x,y) x&=~(1<<y)

#define bP 0 // pin 14 do not use pinMode and digitalWrite
#define POn  bitSet   (PORTC,bP)
#define POff bitClear (PORTC,bP)
void SetupWS28() { bitSet (DDRC,bP); cli();}

// delay() does block the program is interrupt off
#define Calib1ms 900  // 1ms  16 MHz  
void delMs (int dm) { 
   for (volatile int i=0; i<dm; i++) {
      for (volatile int j=0; j<Calib1ms; j++) {}
   }
}
#define nop asm ("nop")
void S8 ( byte dd ) {
  volatile byte cc=0;
  while (cc++ < 8) { 
    POn; nop; nop; nop;  // 2 3 4  nop at 16 MHz
    if (!(dd&0x80)) { POff;}
    nop; nop; nop; POff;    // 4 3 2 1 nop
    dd <<=1;
  }
}
void RGB( byte rr, byte gg, byte bb ) {
  S8(gg); S8(rr); S8(bb);
}
void Show() {  // delay 350 us
 for (volatile int j=0; j<300; j++) {} 
}
void Clear() {
  for (byte i=0;i<Npix;i++) { 
     RGB (0,0,0);
  }
  Show();
}

byte taConv [32]={0,2,3,4, 5,6,7,8, \
           9,10,11,12, 14,16,18,20, \
          23,27,32,37, 43,51,62,68, \
    83,100,120,144,168, 198,224,255}; 

byte Conv (byte vv) {
  return (taConv [vv/8]);
}

void LogRGB( byte rr, byte gg, byte bb ) {
  S8(taConv [gg/8]); S8(taConv [rr/8]); S8(taConv [bb/8]);
}

uint16_t zr,zg,zb;
byte e;
void HtoRGB (uint8_t h) {
   uint16_t xr,xg,xb;  
  e = h/32 ;  // 8 zones
  switch (e) {
    case 0: xr=(96-h)*8   ; xg=h*8  ;       xb=0  ; break;
    case 1: xr=160*3      ; xg=h*8  ;       xb=0  ; break;
    case 2: xr=(96-h)*16  ; xg=h*8  ;       xb=0  ; break;
    case 3: xr=0          ; xg=(192-h)*8  ; xb=(h-96)*8   ; break;
    case 4: xr=0          ; xg=(160-h)*16 ; xb=(h-112)*16 ; break;
    case 5: xr=(h-160)*8  ; xg= 0 ;         xb=(256-h)*8  ; break;
    case 6: xr=(h-160)*8  ; xg= 0 ;         xb=(256-h)*8  ;break;
    case 7: xr=(h-160)*8  ; xg= 0 ;         xb=(256-h)*8  ; break;
  }
  zr=(xr*85)/256; zg=(xg*85)/256; zb=(xb*85)/256;
}

void Hue (byte hh) {
  uint16_t xr,xg,xb;  
  e = hh/32 ;  // 8 zones
  switch (e) {
    case 0: xr=(96-hh)*8  ; xg=hh*8  ;       xb=0  ; break;
    case 1: xr=160*3      ; xg=hh*8  ;       xb=0  ; break;
    case 2: xr=(96-hh)*16 ; xg=hh*8  ;       xb=0  ; break;
    case 3: xr=0          ; xg=(192-hh)*8  ; xb=(hh-96)*8   ; break;
    case 4: xr=0          ; xg=(160-hh)*16 ; xb=(hh-112)*16 ; break;
    case 5: xr=(hh-160)*8 ; xg= 0 ;         xb=(256-hh)*8  ; break;
    case 6: xr=(hh-160)*8 ; xg= 0 ;         xb=(256-hh)*8  ;break;
    case 7: xr=(hh-160)*8 ; xg= 0 ;         xb=(256-hh)*8  ; break;
  }
  RGB (xr,xg,xb);
}


