// WS28.h  ref with Hue 170402
#include <Arduino.h>  // replace next definitions
//typedef uint8_t byte;
//#define bitSet(x,y) x|=(1<<y)
//#define bitClear(x,y) x&=~(1<<y)

#define bP 0 // pin 14 do not use pinMode and digitalWrite
#define POn  bitSet   (PORTC,bP)
#define POff bitClear (PORTC,bP)
void SetupWS28() { bitSet (DDRC,bP); cli();}

// delay() does block the program is interrupt off
#define Calib1ms 900  // 1ms  16 MHz  
void delMs (int dm) { 
   for (volatile int i=0; i<dm; i++) {
      for (volatile int j=0; j<Calib1ms; j++) {}
   }
}
#define nop asm ("nop")
void S8 ( byte dd ) {
  volatile byte cc=0;
  while (cc++ < 8) { 
    POn; nop; nop; nop;  // 2 3 4  nop at 16 MHz
    if (!(dd&0x80)) { POff;}
    nop; nop; nop; POff;    // 4 3 2 1 nop
    dd <<=1;
  }
}
void RGB( byte rr, byte gg, byte bb ) {
  S8(gg); S8(rr); S8(bb);
}
void Show() {  // delay 350 us
 for (volatile int j=0; j<100; j++) {} 
}
void Clear() {
  for (byte i=0;i<Npix;i++) { RGB (0,0,0); }
  Show();
}

byte taConv [32]={0,2,3,4, 5,6,7,8, \
           9,10,11,12, 14,16,18,20, \
          23,27,32,37, 43,51,62,68, \
    83,100,120,144,168, 198,224,255}; 

byte Conv (byte vv) {
  return (taConv [vv/8]);
}

void LogRGB( byte rr, byte gg, byte bb ) {
  S8(taConv [gg/8]); S8(taConv [rr/8]); S8(taConv [bb/8]);
}
byte xx,yy; // global for test
uint16_t xr,xg,xb;

byte ee;
void HtoRGBsimple(byte h) {  // 0-255
   h = h/2;  ee=(h>>6);
   xx=ee;
 switch (ee) { 
   case 0:   // 0-63  hini 0-71  red diminue g augm
    xr=64-h; xg=h; xb=0; break;
   case 1:  // 64-127
    xr=0; xg=127-h; xb=h-64; break;
   case 2:  // 128-pas utilisé
    xr=h-128; xg=0; xb=191-h; break;
   default:
    // ignore
    break; 
   }  // end switch
   xr=xr*4; xg=xg*4; xb=xb*4;
   xx=xr; yy=xg;
}  
byte hueBrtVal= DefaultHueBrt;
void HueBrt(byte vv) {
  hueBrtVal=vv;
}
void Hue (byte hh) {
   HtoRGBsimple(hh);
   xr = (xr*hueBrtVal)/256;
   xg = (xg*hueBrtVal)/256;
   xb = (xb*hueBrtVal)/256;
   RGB(xr,xg,xb);
}


